namespace Entidades
{
    public enum TipoCliente
    {
        Estandar = 1,
        VIP = 2
    }

    public enum TipoPuesto
    {
        EscritorioIndividual = 1,
        SalaReuniones = 2,
        CabinaPrivada = 3
    }

    public enum EstadoReserva
    {
        Confirmada = 1,
        Cancelada = 2,
        Finalizada = 3
    }
}
