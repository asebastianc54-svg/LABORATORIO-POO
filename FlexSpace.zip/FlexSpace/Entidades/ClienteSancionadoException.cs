using System;

namespace Entidades
{
    public class ClienteSancionadoException : Exception
    {
        public ClienteSancionadoException(string mensaje) : base(mensaje)
        {
        }
    }
}
