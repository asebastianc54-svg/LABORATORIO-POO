using System;
using System.Collections.Generic;
using Entidades;
using Datos;

namespace Negocio
{
    public class ReservaBLL
    {
        private ClienteDAL clienteDAL = new ClienteDAL();
        private PuestoDAL puestoDAL = new PuestoDAL();
        private ReservaDAL reservaDAL = new ReservaDAL();

        public decimal CalcularTarifa(Cliente cliente, Puesto puesto, DateTime fechaInicio, DateTime fechaFin)
        {
            if (fechaFin <= fechaInicio)
            {
                throw new ArgumentException("La fecha de fin debe ser posterior a la fecha de inicio.");
            }

            double horas = (fechaFin - fechaInicio).TotalHours;

            // Subtotal base
            decimal subtotal = puesto.TarifaBasePorHora * (decimal)horas;

            // Si tiene sanciones se le suma 20% y no se aplican descuentos
            if (cliente.SancionesActivas > 0)
            {
                return Math.Round(subtotal * 1.20m, 2);
            }

            decimal total = subtotal;

            // Recargo de fin de semana: +15%
            if (ContieneFinDeSemana(fechaInicio, fechaFin))
            {
                total = total + subtotal * 0.15m;
            }

            // Descuento por 5 horas o mas: 10%
            if (horas >= 5)
            {
                total = total - total * 0.10m;
            }

            // Descuento VIP: 5%
            if (cliente.TipoCliente == TipoCliente.VIP)
            {
                total = total - total * 0.05m;
            }

            return Math.Round(total, 2);
        }

        public Reserva RegistrarReserva(int clienteId, int puestoId, DateTime fechaInicio, DateTime fechaFin)
        {
            Cliente cliente = clienteDAL.ObtenerPorId(clienteId);
            if (cliente == null)
            {
                throw new Exception("El cliente no existe.");
            }

            // Con 3 o mas sanciones el cliente queda bloqueado
            if (cliente.SancionesActivas >= 3)
            {
                throw new ClienteSancionadoException("El cliente " + cliente.Nombre + " esta bloqueado por tener " + cliente.SancionesActivas + " sanciones.");
            }

            Puesto puesto = puestoDAL.ObtenerPorId(puestoId);
            if (puesto == null)
            {
                throw new Exception("El puesto no existe.");
            }

            if (reservaDAL.ExisteSolapamiento(puestoId, fechaInicio, fechaFin))
            {
                throw new InvalidOperationException("El puesto ya tiene una reserva en ese horario.");
            }

            Reserva reserva = new Reserva();
            reserva.ClienteId = clienteId;
            reserva.PuestoId = puestoId;
            reserva.FechaInicio = fechaInicio;
            reserva.FechaFin = fechaFin;
            reserva.Estado = EstadoReserva.Confirmada;
            reserva.CostoTotal = CalcularTarifa(cliente, puesto, fechaInicio, fechaFin);

            reservaDAL.Insertar(reserva);
            return reserva;
        }

        public void CancelarReserva(int reservaId)
        {
            Reserva reserva = reservaDAL.ObtenerPorId(reservaId);
            if (reserva == null)
            {
                throw new Exception("No se encontro la reserva.");
            }

            if (reserva.Estado == EstadoReserva.Cancelada)
            {
                throw new InvalidOperationException("La reserva ya estaba cancelada.");
            }

            // Si cancela con menos de 2 horas de anticipacion recibe una sancion
            TimeSpan diferencia = reserva.FechaInicio - DateTime.Now;
            if (diferencia.TotalHours < 2)
            {
                clienteDAL.IncrementarSancion(reserva.ClienteId);
            }

            reservaDAL.ActualizarEstado(reservaId, EstadoReserva.Cancelada);
        }

        public List<Reserva> ConsultarReservasActivasPorPuesto(string codigoPuesto)
        {
            Puesto puesto = puestoDAL.ObtenerPorCodigo(codigoPuesto);
            if (puesto == null)
            {
                throw new Exception("No existe un puesto con ese codigo.");
            }

            return reservaDAL.ObtenerActivasPorPuesto(puesto.Id);
        }

        public List<Cliente> ListarClientesSancionados()
        {
            return clienteDAL.ObtenerSancionados();
        }

        // Recorre cada dia entre el inicio y el fin y mira si es sabado o domingo
        private bool ContieneFinDeSemana(DateTime inicio, DateTime fin)
        {
            DateTime dia = inicio.Date;
            while (dia <= fin)
            {
                if (dia.DayOfWeek == DayOfWeek.Saturday || dia.DayOfWeek == DayOfWeek.Sunday)
                {
                    return true;
                }
                dia = dia.AddDays(1);
            }
            return false;
        }
    }
}
