using System;
using System.Collections.Generic;
using Entidades;

namespace Datos
{
    public class PuestoDAL
    {
        private static List<Puesto> puestos = new List<Puesto>()
        {
            new Puesto { Id = 1, Codigo = "ESC-01", TipoPuesto = TipoPuesto.EscritorioIndividual, TarifaBasePorHora = 1500m },
            new Puesto { Id = 2, Codigo = "SAL-01", TipoPuesto = TipoPuesto.SalaReuniones, TarifaBasePorHora = 4500m },
            new Puesto { Id = 3, Codigo = "CAB-01", TipoPuesto = TipoPuesto.CabinaPrivada, TarifaBasePorHora = 2500m }
        };

        public Puesto ObtenerPorId(int id)
        {
            foreach (Puesto p in puestos)
            {
                if (p.Id == id)
                {
                    return p;
                }
            }
            return null;
        }

        public Puesto ObtenerPorCodigo(string codigo)
        {
            foreach (Puesto p in puestos)
            {
                if (p.Codigo.ToUpper() == codigo.ToUpper())
                {
                    return p;
                }
            }
            return null;
        }
    }
}
