using System.Collections.Generic;
using Entidades;

namespace Datos
{
    public class ClienteDAL
    {
        // Lista en memoria que hace de "base de datos"
        private static List<Cliente> clientes = new List<Cliente>()
        {
            new Cliente { Id = 1, Nombre = "Juan Perez", Email = "juan.perez@test.com", TipoCliente = TipoCliente.Estandar, SancionesActivas = 0 },
            new Cliente { Id = 2, Nombre = "Lucia Gomez", Email = "lucia.gomez@test.com", TipoCliente = TipoCliente.VIP, SancionesActivas = 0 },
            new Cliente { Id = 3, Nombre = "Marcos Lopez", Email = "marcos.lopez@test.com", TipoCliente = TipoCliente.Estandar, SancionesActivas = 3 }
        };

        public Cliente ObtenerPorId(int id)
        {
            foreach (Cliente c in clientes)
            {
                if (c.Id == id)
                {
                    return c;
                }
            }
            return null;
        }

        public void IncrementarSancion(int clienteId)
        {
            Cliente cliente = ObtenerPorId(clienteId);
            if (cliente != null)
            {
                cliente.SancionesActivas++;
            }
        }

        public List<Cliente> ObtenerSancionados()
        {
            List<Cliente> sancionados = new List<Cliente>();
            foreach (Cliente c in clientes)
            {
                if (c.SancionesActivas > 0)
                {
                    sancionados.Add(c);
                }
            }
            return sancionados;
        }
    }
}
