using System;
using System.Collections.Generic;
using Entidades;

namespace Datos
{
    public class ReservaDAL
    {
        private static List<Reserva> reservas = new List<Reserva>();
        private static int proximoId = 1;

        public bool ExisteSolapamiento(int puestoId, DateTime fechaInicio, DateTime fechaFin)
        {
            foreach (Reserva r in reservas)
            {
                if (r.PuestoId == puestoId && r.Estado == EstadoReserva.Confirmada)
                {
                    if (fechaInicio < r.FechaFin && fechaFin > r.FechaInicio)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void Insertar(Reserva reserva)
        {
            reserva.Id = proximoId;
            proximoId++;
            reservas.Add(reserva);
        }

        public Reserva ObtenerPorId(int id)
        {
            foreach (Reserva r in reservas)
            {
                if (r.Id == id)
                {
                    return r;
                }
            }
            return null;
        }

        public void ActualizarEstado(int reservaId, EstadoReserva nuevoEstado)
        {
            Reserva reserva = ObtenerPorId(reservaId);
            if (reserva != null)
            {
                reserva.Estado = nuevoEstado;
            }
        }

        public List<Reserva> ObtenerActivasPorPuesto(int puestoId)
        {
            List<Reserva> activas = new List<Reserva>();
            foreach (Reserva r in reservas)
            {
                if (r.PuestoId == puestoId && r.Estado == EstadoReserva.Confirmada && r.FechaFin >= DateTime.Now)
                {
                    activas.Add(r);
                }
            }
            return activas;
        }
    }
}
