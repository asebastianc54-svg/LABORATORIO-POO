using System;
using System.Collections.Generic;
using Entidades;
using Negocio;

namespace Presentacion
{
    class Program
    {
        static ReservaBLL reservaBLL = new ReservaBLL();

        static void Main(string[] args)
        {
            bool salir = false;

            while (!salir)
            {
                Console.Clear();
                Console.WriteLine("========================================");
                Console.WriteLine("        FLEXSPACE - RESERVAS");
                Console.WriteLine("========================================");
                Console.WriteLine("1. Registrar nueva reserva");
                Console.WriteLine("2. Cancelar reserva");
                Console.WriteLine("3. Consultar reservas activas por puesto");
                Console.WriteLine("4. Listar clientes sancionados");
                Console.WriteLine("5. Salir");
                Console.WriteLine("========================================");
                Console.Write("Seleccione una opcion: ");

                string opcion = Console.ReadLine();

                if (opcion == "1")
                {
                    RegistrarReserva();
                }
                else if (opcion == "2")
                {
                    CancelarReserva();
                }
                else if (opcion == "3")
                {
                    ConsultarReservas();
                }
                else if (opcion == "4")
                {
                    ListarSancionados();
                }
                else if (opcion == "5")
                {
                    salir = true;
                }
                else
                {
                    Console.WriteLine("Opcion no valida.");
                    Console.ReadKey();
                }
            }
        }

        static void RegistrarReserva()
        {
            Console.Clear();
            Console.WriteLine("--- REGISTRO DE RESERVA ---");

            try
            {
                Console.Write("ID del cliente (1: Juan Perez, 2: Lucia Gomez [VIP], 3: Marcos Lopez [Sancionado]): ");
                int clienteId = int.Parse(Console.ReadLine());

                Console.Write("ID del puesto (1: ESC-01, 2: SAL-01, 3: CAB-01): ");
                int puestoId = int.Parse(Console.ReadLine());

                Console.Write("Fecha y hora de inicio (yyyy-MM-dd HH:mm): ");
                DateTime inicio = DateTime.Parse(Console.ReadLine());

                Console.Write("Fecha y hora de fin (yyyy-MM-dd HH:mm): ");
                DateTime fin = DateTime.Parse(Console.ReadLine());

                Reserva reserva = reservaBLL.RegistrarReserva(clienteId, puestoId, inicio, fin);

                Console.WriteLine();
                Console.WriteLine("Reserva registrada correctamente.");
                Console.WriteLine("ID de reserva: " + reserva.Id + " | Monto final: $" + reserva.CostoTotal);
            }
            catch (ClienteSancionadoException ex)
            {
                Console.WriteLine();
                Console.WriteLine("RECHAZADO: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine("ERROR: " + ex.Message);
            }

            Pausar();
        }

        static void CancelarReserva()
        {
            Console.Clear();
            Console.WriteLine("--- CANCELAR RESERVA ---");

            try
            {
                Console.Write("ID de la reserva: ");
                int reservaId = int.Parse(Console.ReadLine());

                reservaBLL.CancelarReserva(reservaId);
                Console.WriteLine();
                Console.WriteLine("Reserva cancelada.");
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine("ERROR: " + ex.Message);
            }

            Pausar();
        }

        static void ConsultarReservas()
        {
            Console.Clear();
            Console.WriteLine("--- RESERVAS ACTIVAS POR PUESTO ---");

            try
            {
                Console.Write("Codigo del puesto (ESC-01, SAL-01, CAB-01): ");
                string codigo = Console.ReadLine();

                List<Reserva> lista = reservaBLL.ConsultarReservasActivasPorPuesto(codigo);

                Console.WriteLine();
                Console.WriteLine("Reservas encontradas: " + lista.Count);
                foreach (Reserva r in lista)
                {
                    Console.WriteLine("ID: " + r.Id + " | Cliente: " + r.ClienteId + " | Inicio: " + r.FechaInicio + " | Fin: " + r.FechaFin + " | Costo: $" + r.CostoTotal);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine("ERROR: " + ex.Message);
            }

            Pausar();
        }

        static void ListarSancionados()
        {
            Console.Clear();
            Console.WriteLine("--- CLIENTES SANCIONADOS ---");

            try
            {
                List<Cliente> sancionados = reservaBLL.ListarClientesSancionados();

                if (sancionados.Count == 0)
                {
                    Console.WriteLine("No hay clientes sancionados.");
                }
                else
                {
                    foreach (Cliente c in sancionados)
                    {
                        Console.WriteLine("ID: " + c.Id + " | Nombre: " + c.Nombre + " | Sanciones: " + c.SancionesActivas);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine("ERROR: " + ex.Message);
            }

            Pausar();
        }

        static void Pausar()
        {
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadKey();
        }
    }
}
